package com.example.demo.service;

import com.example.demo.entity.User;
import java.util.List;

public interface UserService {
    User saveUser(User user); // Unified add/update method
    List<User> getAllUsers();
    User getUserById(Integer id);
    void deleteUserById(Integer id);
}
